package com.example.craftzone.activities.admin

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.craftzone.Data.ProductItem
import com.example.craftzone.R
import com.example.craftzone.databinding.ActivityReceiveAllItemsBinding
import com.google.firebase.firestore.FirebaseFirestore

@Suppress("DEPRECATION")
class deleteAdmin : AppCompatActivity() {
    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var title: TextView
    private lateinit var description: TextView
    private lateinit var price1: TextView
    private lateinit var image: ImageView
    private lateinit var sharedpref: SharedPreferences
    private lateinit var email: String
    private lateinit var binding: ActivityReceiveAllItemsBinding
    private var uri: Uri? = null
    private lateinit var ImageString: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReceiveAllItemsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        title = findViewById(R.id.title)
        description = findViewById(R.id.description)
        price1 = findViewById(R.id.price1)
        image = findViewById(R.id.image)

        sharedpref = getSharedPreferences("my_pre", Context.MODE_PRIVATE)
        email = sharedpref.getString("email", "").toString()

        val food = intent.getParcelableExtra<ProductItem>("food")

        title.text = food?.name
        price1.text = food?.price.toString()
        description.text = food?.des

        ImageString = food?.image.toString()

        val imageView = food?.image
        uri = Uri.parse(imageView)
        Glide.with(this).load(uri).into(image)

        firebaseFirestore = FirebaseFirestore.getInstance()

        binding.deleteToCart.setOnClickListener {
            uploadImage()
            binding.constraint.alpha = 0.3F
            binding.progressBar2.visibility = View.VISIBLE
            binding.wait.visibility = View.VISIBLE
            binding.constraint1.visibility = View.VISIBLE
        }
    }
    private fun uploadImage() {
        if (ImageString.isNotEmpty()) {
            val productQuery = firebaseFirestore.collection("ProductDetails")
                .whereEqualTo("pic", uri.toString())
                .get()
            productQuery.addOnSuccessListener {
                for (document in it) {
                    firebaseFirestore.collection("ProductDetails").document(document.id).delete()
                        .addOnSuccessListener {
                            Toast.makeText(
                                this,
                                "product deleted",
                                Toast.LENGTH_SHORT
                            ).show()
                            binding.constraint.alpha = 1F
                            binding.progressBar2.visibility = View.INVISIBLE
                            binding.wait.visibility = View.INVISIBLE
                            binding.constraint1.visibility = View.INVISIBLE
//                            recreate()
                            startActivity(Intent(this, deleteAdmin::class.java))
                            finish()
//                          supportFragmentManager
//                            .beginTransaction()
//                            .replace(R.id.frameLayout, AddToCart())
//                            .addToBackStack("HomeFragment")
//                            .commit()
                        }
                }
            }
        } else {
            binding.constraint.alpha = 1F
            binding.progressBar2.visibility = View.INVISIBLE
            binding.wait.visibility = View.INVISIBLE
            binding.constraint1.visibility = View.INVISIBLE
            Toast.makeText(this@deleteAdmin, "Something wen't Wrong!", Toast.LENGTH_SHORT)
                .show()
        }
    }
}